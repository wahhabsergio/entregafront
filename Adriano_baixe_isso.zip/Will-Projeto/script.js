$(document).ready(function() {
    $('#mobile-btn').on('click', function () {
        $('#mobile-menu').toggLeClass('active');
        $('#mobile-btn').find('i').toggLeClass('fa-x');
        
    })
})